# TTS 整合指南

## 快速開始

### 1. 確保 QWEN3-TTS HTTP 服務運行

在 Windows 上啟動 qwen3-tts-http 服務：
```bash
# 預設監聽 http://localhost:5000
python app.py
```

### 2. 測試 TTS 功能

```bash
cd story_chain_multiverse

# 給腳本執行權限
chmod +x scripts/tts_call.sh

# 測試生成語音
./scripts/tts_call.sh "這是一個測試，檢查語音是否正常生成。" test.mp3
```

### 3. 在遊戲中使用

當玩家開啟語音功能後，每輪故事生成流程：

```bash
# 1. 生成故事文本（由 agent 完成）
STORY_TEXT="📖\n你走進了一間古老的書店，空氣中瀰漫著紙張的香氣……"

# 2. 清理文本
CLEAN_TEXT=$(python3 scripts/clean_text_for_tts.py "$STORY_TEXT")

# 3. 生成語音
./scripts/tts_call.sh "$CLEAN_TEXT" "story_round_01.mp3"

# 4. 播放或傳送給玩家
# （具體方式依平台而定：Telegram、WhatsApp、Discord 等）
```

## 使用範例

### 範例 1：基礎故事朗讀

**輸入文本：**
```
📖
你站在十字路口，前方是繁華的城市，身後是寧靜的森林。
一個神秘的聲音在你腦海中響起：「選擇吧，冒險者。」

你可以選擇：
1. 走向城市
2. 回到森林
3. 原地等待
```

**清理後文本：**
```
你站在十字路口，前方是繁華的城市，身後是寧靜的森林。
一個神秘的聲音在你腦海中響起：「選擇吧，冒險者。」
```

**生成指令：**
```bash
python3 scripts/clean_text_for_tts.py "$STORY_TEXT" | \
  xargs -I {} ./scripts/tts_call.sh "{}" story_01.mp3
```

### 範例 2：語音克隆（進階）

**準備角色聲音：**
1. 準備 10+ 秒清晰人聲音檔（如 `hero_voice.mp3`）
2. 使用 QWEN3-TTS demo 生成 `voice_clone_prompt`
3. 儲存為 `voices/hero.json`

**使用克隆聲音：**
```bash
# 在 API 請求中指定 voice_prompt 參數
curl -X POST http://localhost:5000/tts \
  -H "Content-Type: application/json" \
  -d '{
    "text": "這是主角的聲音",
    "voice_prompt": "voices/hero.json",
    "output": "hero_line.mp3"
  }' \
  -o hero_line.mp3
```

## Agent 整合模式

### 在 OpenClaw agent 中使用

當 agent 生成故事時，自動判斷是否需要語音輸出：

```python
# 偽代碼示例
def generate_story_response(user_input, tts_enabled=False):
    # 1. 生成故事文本
    story_text = generate_story(user_input)
    
    # 2. 顯示文字
    send_message(story_text)
    
    # 3. 如果啟用 TTS
    if tts_enabled:
        # 清理文本
        clean_text = clean_for_tts(story_text)
        
        # 生成語音（背景執行）
        audio_file = call_tts_api(clean_text)
        
        # 傳送語音
        send_audio(audio_file)
    
    return story_text
```

### 狀態管理

在遊戲 session 中維護 TTS 狀態：

```json
{
  "game_id": "story_20260226_001",
  "tts_config": {
    "enabled": true,
    "mode": "narrator",
    "voices": {
      "narrator": "default",
      "hero": "voices/hero.json",
      "villain": "voices/villain.json"
    }
  },
  "current_round": 5,
  "audio_history": [
    "story_round_01.mp3",
    "story_round_02.mp3",
    "story_round_03.mp3"
  ]
}
```

## 故障排除

### TTS 服務無法連線
```bash
# 檢查服務是否運行
curl http://localhost:5000/health

# 如果失敗，重啟服務
cd ~/qwen3-tts-http
python app.py
```

### 語音生成失敗
- 檢查文本長度（建議 < 500 字）
- 檢查特殊字符（移除 emoji 和符號）
- 查看服務日誌確認錯誤

### 語音品質問題
- 使用清晰的克隆音源（無背景音、無雜訊）
- 音源長度至少 10 秒
- 確保 RTX GPU 正常工作

## 效能優化

### 批次生成
長文本自動切分為多段，並行生成：

```bash
# 分段生成（由 clean_text_for_tts.py 自動切分）
python3 scripts/clean_text_for_tts.py "$LONG_TEXT" | \
  while IFS= read -r segment; do
    ./scripts/tts_call.sh "$segment" "segment_$(date +%s).mp3"
  done
```

### 快取機制
常見文本（如「你可以選擇」）可預先生成並重複使用。

### 清理舊檔案
定期清理音檔節省空間：

```bash
# 清理 7 天前的音檔
find . -name "story_*.mp3" -mtime +7 -delete
```

## 進階功能

### 多角色對話
檢測對話內容，自動切換聲音：

```
「你是誰？」主角問道。
「我是這片森林的守護者。」神秘聲音回答。
```

可分別用不同聲音生成：
- 主角的話 → hero voice
- 神秘聲音 → narrator voice

### 背景音效
在語音生成後，疊加背景音效：

```bash
# 使用 ffmpeg 混音
ffmpeg -i story.mp3 -i forest_ambient.mp3 \
  -filter_complex amix=inputs=2:duration=first \
  story_with_bgm.mp3
```

---

**提示：**TTS 功能為可選增強，不影響核心遊戲體驗。玩家可隨時開啟或關閉。
